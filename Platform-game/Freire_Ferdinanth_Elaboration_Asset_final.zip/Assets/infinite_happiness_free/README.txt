Infinite Happiness FREE : SETUP GUIDE
Dear Unity Developer,
Thank you for downloading this package taking interest in my work!

This Asset contains:
- 2 tracks in 2 different versions (loopable and non-loopable). One is "light" intensity, the other is "stronger" intensity.

The PRO version features:
- Fully randomized and interactive music, procedurally generated!
- A unique prefab for instant drag and drop "in game" integration.
- Two intensity levels.
- The possibility to change the tempo/pitch: three levels.
- 18 different melodies (9 guitar solos, 9 celesta solos)
- 16 different accompaniments (9 guitar loops, 8 marimba loops)
- 4x3 different percussion loops and more!
Check it out on the Unity Assetstore!

I hope you'll be able to make use of this!
Don't forget to leave a review and suggestions/ideas for how to make this work even better!

Thanks again for your support and don't hesitate to contact me if you have any questions/suggestions! 

sincerely,

Marma

CONTACT: marma.developer@gmail.com
WEBSITE: http://www.marmamusic.com